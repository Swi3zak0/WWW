<?php
    $color = 'niebieski';
    $wiek = '22'
?>