<?php
    return 'Użycie require_once';
?>