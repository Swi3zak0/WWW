<!DOCTYPE html>
<html>
    <head>
		<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
		<meta http-equiv="Content-Language" content="pl" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="Author" content="Patrycjusz Siwek" />
		<link rel="stylesheet" href="css/arkusz.css">
		<title>Moje hobby to koszykówka</title>
        <script src="js/kolorujtlo.js" type="text/javascript"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	</head>
    <body>
        <form class="buttoms" method="post" name="background">
            <input type="button" value="yellow" onclick="changeBackground('#FFF000')">
            <input type="button" value="black" onclick="changeBackground('#000000')">
            <input type="button" value="white" onclick="changeBackground('FFFFFF')">
            <input type="button" value="green" onclick="changeBackground('00FF00')">
            <input type="button" value="blue" onclick="changeBackground('0000FF')">
            <input type="button" value="orange" onclick="changeBackground('FF8000')">
            <input type="button" value="grey" onclick="changeBackground('c0c0c0')">
            <input type="button" value="red" onclick="changeBackground('FF0000')">
        </form>
        <div id="main">
            <nav>
                <a class="option main" href="index.php?idp=">Strona Główna</a><a class="option" href="index.php?idp=historia">Historia</a><a class="option" href="index.php?idp=druzyny">Drużyny</a><a class="option" href="index.php?idp=gwiazdy">Gwiazdy NBA</a><a class="option" href="index.php?idp=kontakt">Kontakt</a>
            </nav>
        </div>
        <?php
            error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);

            if($_GET['idp'] == '') $strona = '/html/glowna.html';
            if($_GET['idp'] == 'historia') $strona = '/html/historia.html';
            if($_GET['idp'] == 'druzyny') $strona = '/html/druzyny.html';
            if($_GET['idp'] == 'gwiazdy') $strona = '/html/gwiazdy.html';
            if($_GET['idp'] == 'kontakt') $strona = '/html/kontakt.html';
            ?>
        <?php
            if (file_exists($strona)) {
                include($strona);
            }
        ?>
        <?php
            $nr_indeksu = '164463';
            $nrGrupy = '1';
            echo 'Autor: Patrycjusz Siwek '.$nr_indeksu.' grupa '.$nrGrupy.' <br /><br />';
            ?>
    </body>
</html>

