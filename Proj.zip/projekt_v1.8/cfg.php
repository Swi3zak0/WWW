<?php
    $user = 'admin';
    $pass = 'admin';
function db_connect(){
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $baza = 'mojastrona';
    {
        $link = new mysqli($dbhost, $dbuser, $dbpass, $baza);

        if ($link->connect_error) {
            die("Zerwane połaczenie: " . $link->connect_error);
        }
        return $link;
    }
}

